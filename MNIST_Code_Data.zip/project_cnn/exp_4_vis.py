import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
import pickle
import numpy as np
from matplotlib.font_manager import FontProperties
from matplotlib.ticker import MaxNLocator

nums = 5

# Load all the pickle data
pkl_data = []
for seed_idx in range(10):
    # Step 1: Open the pickle file in read-binary mode
    with open(f'/project_cnn/exp_4_run={seed_idx}.pkl', 'rb') as file:
        # Step 2: Load the data from the file
        data = pickle.load(file)
    pkl_data.append(data)

# Load the loss and accuracy values
train_losses_cnn_list_diag_all = []
test_losses_cnn_list_diag_all = []
test_accs_cnn_list_diag_all = []
train_losses_cnn_list_left_all = []
test_losses_cnn_list_left_all = []
test_accs_cnn_list_left_all = []
train_losses_cnn_list_inner_all = []
test_losses_cnn_list_inner_all = []
test_accs_cnn_list_inner_all = []
train_losses_cnn_list_outer_all = []
test_losses_cnn_list_outer_all = []
test_accs_cnn_list_outer_all = []
train_losses_cnn_list_random_all = []
test_losses_cnn_list_random_all = []
test_accs_cnn_list_random_all = []
train_losses_cnn_list_fix_all = []
test_losses_cnn_list_fix_all = []
test_accs_cnn_list_fix_all = []

for seed_idx in range(10):
    train_losses_cnn_list_diag_seed = []
    test_losses_cnn_list_diag_seed = []
    test_accs_cnn_list_diag_seed = []
    train_losses_cnn_list_left_seed = []
    test_losses_cnn_list_left_seed = []
    test_accs_cnn_list_left_seed = []
    train_losses_cnn_list_inner_seed = []
    test_losses_cnn_list_inner_seed = []
    test_accs_cnn_list_inner_seed = []
    train_losses_cnn_list_outer_seed = []
    test_losses_cnn_list_outer_seed = []
    test_accs_cnn_list_outer_seed = []
    train_losses_cnn_list_random_seed = []
    test_losses_cnn_list_random_seed = []
    test_accs_cnn_list_random_seed = []
    train_losses_cnn_list_fix_seed = []
    test_losses_cnn_list_fix_seed = []
    test_accs_cnn_list_fix_seed = []
    for j in range(5):
        train_losses_cnn_list_diag_seed.append(pkl_data[seed_idx]["train_losses_cnn_list_diag"][j][-1])
        test_losses_cnn_list_diag_seed.append(pkl_data[seed_idx]["test_losses_cnn_list_diag"][j][-1])
        test_accs_cnn_list_diag_seed.append(pkl_data[seed_idx]["test_accs_cnn_list_diag"][j][-1])
        train_losses_cnn_list_left_seed.append(pkl_data[seed_idx]["train_losses_cnn_list_left"][j][-1])
        test_losses_cnn_list_left_seed.append(pkl_data[seed_idx]["test_losses_cnn_list_left"][j][-1])
        test_accs_cnn_list_left_seed.append(pkl_data[seed_idx]["test_accs_cnn_list_left"][j][-1])
        train_losses_cnn_list_inner_seed.append(pkl_data[seed_idx]["train_losses_cnn_list_inner"][j][-1])
        test_losses_cnn_list_inner_seed.append(pkl_data[seed_idx]["test_losses_cnn_list_inner"][j][-1])
        test_accs_cnn_list_inner_seed.append(pkl_data[seed_idx]["test_accs_cnn_list_inner"][j][-1])
        train_losses_cnn_list_outer_seed.append(pkl_data[seed_idx]["train_losses_cnn_list_outer"][j][-1])
        test_losses_cnn_list_outer_seed.append(pkl_data[seed_idx]["test_losses_cnn_list_outer"][j][-1])
        test_accs_cnn_list_outer_seed.append(pkl_data[seed_idx]["test_accs_cnn_list_outer"][j][-1])
        train_losses_cnn_list_random_seed.append(pkl_data[seed_idx]["train_losses_cnn_list_random"][j][-1])
        test_losses_cnn_list_random_seed.append(pkl_data[seed_idx]["test_losses_cnn_list_random"][j][-1])
        test_accs_cnn_list_random_seed.append(pkl_data[seed_idx]["test_accs_cnn_list_random"][j][-1])
        train_losses_cnn_list_fix_seed.append(pkl_data[seed_idx]["train_losses_cnn_list_fix"][j][-1])
        test_losses_cnn_list_fix_seed.append(pkl_data[seed_idx]["test_losses_cnn_list_fix"][j][-1])
        test_accs_cnn_list_fix_seed.append(pkl_data[seed_idx]["test_accs_cnn_list_fix"][j][-1])
    train_losses_cnn_list_diag_all.append(train_losses_cnn_list_diag_seed)
    test_losses_cnn_list_diag_all.append(test_losses_cnn_list_diag_seed)
    test_accs_cnn_list_diag_all.append(test_accs_cnn_list_diag_seed)
    train_losses_cnn_list_left_all.append(train_losses_cnn_list_left_seed)
    test_losses_cnn_list_left_all.append(test_losses_cnn_list_left_seed)
    test_accs_cnn_list_left_all.append(test_accs_cnn_list_left_seed)
    train_losses_cnn_list_inner_all.append(train_losses_cnn_list_inner_seed)
    test_losses_cnn_list_inner_all.append(test_losses_cnn_list_inner_seed)
    test_accs_cnn_list_inner_all.append(test_accs_cnn_list_inner_seed)
    train_losses_cnn_list_outer_all.append(train_losses_cnn_list_outer_seed)
    test_losses_cnn_list_outer_all.append(test_losses_cnn_list_outer_seed)
    test_accs_cnn_list_outer_all.append(test_accs_cnn_list_outer_seed)
    train_losses_cnn_list_random_all.append(train_losses_cnn_list_random_seed)
    test_losses_cnn_list_random_all.append(test_losses_cnn_list_random_seed)
    test_accs_cnn_list_random_all.append(test_accs_cnn_list_random_seed)
    train_losses_cnn_list_fix_all.append(train_losses_cnn_list_fix_seed)
    test_losses_cnn_list_fix_all.append(test_losses_cnn_list_fix_seed)
    test_accs_cnn_list_fix_all.append(test_accs_cnn_list_fix_seed)

# Get the mean and standard deviation per run
train_losses_cnn_nums_diag=np.array(train_losses_cnn_list_diag_all).mean(0)
test_losses_cnn_nums_diag=np.array(test_losses_cnn_list_diag_all).mean(0)
test_accs_cnn_nums_diag=np.array(test_accs_cnn_list_diag_all).mean(0)
train_losses_cnn_nums_left=np.array(train_losses_cnn_list_left_all).mean(0)
test_losses_cnn_nums_left=np.array(test_losses_cnn_list_left_all).mean(0)
test_accs_cnn_nums_left=np.array(test_accs_cnn_list_left_all).mean(0)
train_losses_cnn_nums_inner=np.array(train_losses_cnn_list_inner_all).mean(0)
test_losses_cnn_nums_inner=np.array(test_losses_cnn_list_inner_all).mean(0)
test_accs_cnn_nums_inner=np.array(test_accs_cnn_list_inner_all).mean(0)
train_losses_cnn_nums_outer=np.array(train_losses_cnn_list_outer_all).mean(0)
test_losses_cnn_nums_outer=np.array(test_losses_cnn_list_outer_all).mean(0)
test_accs_cnn_nums_outer=np.array(test_accs_cnn_list_outer_all).mean(0)
train_losses_cnn_nums_random=np.array(train_losses_cnn_list_random_all).mean(0)
test_losses_cnn_nums_random=np.array(test_losses_cnn_list_random_all).mean(0)
test_accs_cnn_nums_random=np.array(test_accs_cnn_list_random_all).mean(0)
train_losses_cnn_nums_fix=np.array(train_losses_cnn_list_fix_all).mean(0)
test_losses_cnn_nums_fix=np.array(test_losses_cnn_list_fix_all).mean(0)
test_accs_cnn_nums_fix=np.array(test_accs_cnn_list_fix_all).mean(0)

train_losses_cnn_nums_diag_std=np.array(train_losses_cnn_list_diag_all).std(0)
test_losses_cnn_nums_diag_std=np.array(test_losses_cnn_list_diag_all).std(0)
test_accs_cnn_nums_diag_std=np.array(test_accs_cnn_list_diag_all).std(0)
train_losses_cnn_nums_left_std=np.array(train_losses_cnn_list_left_all).std(0)
test_losses_cnn_nums_left_std=np.array(test_losses_cnn_list_left_all).std(0)
test_accs_cnn_nums_left_std=np.array(test_accs_cnn_list_left_all).std(0)
train_losses_cnn_nums_inner_std=np.array(train_losses_cnn_list_inner_all).std(0)
test_losses_cnn_nums_inner_std=np.array(test_losses_cnn_list_inner_all).std(0)
test_accs_cnn_nums_inner_std=np.array(test_accs_cnn_list_inner_all).std(0)
train_losses_cnn_nums_outer_std=np.array(train_losses_cnn_list_outer_all).std(0)
test_losses_cnn_nums_outer_std=np.array(test_losses_cnn_list_outer_all).std(0)
test_accs_cnn_nums_outer_std=np.array(test_accs_cnn_list_outer_all).std(0)
train_losses_cnn_nums_random_std=np.array(train_losses_cnn_list_random_all).std(0)
test_losses_cnn_nums_random_std=np.array(test_losses_cnn_list_random_all).std(0)
test_accs_cnn_nums_random_std=np.array(test_accs_cnn_list_random_all).std(0)
train_losses_cnn_nums_fix_std=np.array(train_losses_cnn_list_fix_all).std(0)
test_losses_cnn_nums_fix_std=np.array(test_losses_cnn_list_fix_all).std(0)
test_accs_cnn_nums_fix_std=np.array(test_accs_cnn_list_fix_all).std(0)

# Perform the plotting
# Font properties
font_properties_title = {'fontsize': 20, 'fontweight': 'normal', 'fontname': 'serif'}
font_properties_labels = {'fontsize': 18, 'fontweight': 'normal', 'fontname': 'serif'}

from matplotlib.font_manager import FontProperties

# Create FontProperties for serif font
serif_font = FontProperties(family='serif', size=16)
serif_font_legend = FontProperties(family='serif', size=14)

# Plot for Train and Test Loss
# plt.figure(figsize=(8, 6))
_, ax1 = plt.subplots(figsize=(8, 6))
ax1.set_facecolor('#F0F8FF')  # Set the axes background color to a blue shade
plt.plot(range(1,nums+1), train_losses_cnn_nums_diag, label='Diagonal', marker='o', color='red', alpha=0.8)
plt.plot(range(1,nums+1), train_losses_cnn_nums_left, label='Left', marker='o', color='blue', alpha=0.8)
plt.plot(range(1,nums+1), train_losses_cnn_nums_inner, label='Inner', marker='o', color='green', alpha=0.8)
plt.plot(range(1,nums+1), train_losses_cnn_nums_outer, label='Outer', marker='o', color='purple', alpha=0.8)
plt.plot(range(1,nums+1), train_losses_cnn_nums_random, label='Random', marker='o', color='pink', alpha=0.8)
plt.plot(range(1,nums+1), train_losses_cnn_nums_fix, label='Fix', marker='o', color='yellow', alpha=0.8)

plt.xlabel('Number of Repetitions', **font_properties_labels)
plt.ylabel('Loss', **font_properties_labels)
plt.title('Train Loss vs Number of Repetitions', **font_properties_title)
# Set x-axis ticks to only show integers
ax1.xaxis.set_major_locator(MaxNLocator(integer=True))
plt.legend(title='Distribution', title_fontproperties=serif_font_legend, prop=serif_font_legend)
# Set larger font size for tick labels
ax1.tick_params(axis='both', which='major', labelsize=14, labelcolor='black', labelfontfamily='serif')  # Set tick label size for both axes
plt.grid(color='gray', linestyle='--', linewidth=0.5, alpha=0.7)  # Grid with transparency
plt.tight_layout()  # Adjust layout to make it look better
plt.savefig('/project_cnn/exp_4/train_loss.png', bbox_inches='tight')
plt.show()

_, ax3 = plt.subplots(figsize=(8, 6))
ax3.set_facecolor('#F0F8FF')  # Set the axes background color to a blue shade

plt.plot(range(1,nums+1), test_losses_cnn_nums_diag, label='Diagonal', marker='s', color='red', alpha=0.8)
plt.plot(range(1,nums+1), test_losses_cnn_nums_left, label='Left', marker='s', color='blue', alpha=0.8)
plt.plot(range(1,nums+1), test_losses_cnn_nums_inner, label='Inner', marker='s', color='green', alpha=0.8)
plt.plot(range(1,nums+1), test_losses_cnn_nums_outer, label='Outer', marker='s', color='purple', alpha=0.8)
plt.plot(range(1,nums+1), test_losses_cnn_nums_random, label='Random', marker='s', color='pink', alpha=0.8)
plt.plot(range(1,nums+1), test_losses_cnn_nums_fix, label='Fix', marker='s', color='yellow', alpha=0.8)
plt.xlabel('Number of Repetitions', **font_properties_labels)
plt.ylabel('Loss', **font_properties_labels)
plt.title('Test Loss vs Number of Repetitions', **font_properties_title)
# Set x-axis ticks to only show integers
ax3.xaxis.set_major_locator(MaxNLocator(integer=True))
plt.legend(title='Distribution', title_fontproperties=serif_font_legend, prop=serif_font_legend)
# Set larger font size for tick labels
ax3.tick_params(axis='both', which='major', labelsize=14, labelcolor='black', labelfontfamily='serif')  # Set tick label size for both axes
plt.grid(color='gray', linestyle='--', linewidth=0.5, alpha=0.7)  # Grid with transparency
plt.tight_layout()  # Adjust layout to make it look better
plt.savefig('/project_cnn/exp_4/test_loss.png', bbox_inches='tight')
plt.show()


    # '#1f77b4',  # Blue
    # '#aec7e8',  # Light Blue
    # '#0077b3',  # Darker Blue
    # '#2ca02c',  # Teal Blue
    # '#17becf',  # Cyan Blue
    # '#9467bd',  # Purple Blue
    # '#8c564b',  # Brownish Blue
    # '#d62728'   # Redish Blue (for contrast)
    
    # '#FF8C00',  # Dark orange
    # '#FF7F50',  # Coral
    # '#FF6347',  # Tomato
    # '#FF4500',  # Orange red
    # '#FFD700',  # Gold
    # '#FFB733',  # Light orange
    # '#FFAA00',  # Bright orange
    # '#FFCC00',  # Light golden yellow
    # '#FF9933'   # Light orange with a hint of brown
    
# Plot for Test Accuracy
_, ax2 = plt.subplots(figsize=(8, 6))
ax2.set_facecolor('#F0F8FF')  # Set the axes background color to a blue shade
plt.plot(range(1,nums+1), test_accs_cnn_nums_diag*100, label='Diagonal', marker='^', color='red', alpha=0.8)
plt.plot(range(1,nums+1), test_accs_cnn_nums_fix*100, label='Left', marker='^', color='blue', alpha=0.8)
plt.plot(range(1,nums+1), test_accs_cnn_nums_left*100, label='Inner', marker='^', color='green', alpha=0.8)
plt.plot(range(1,nums+1), test_accs_cnn_nums_inner*100, label='Outer', marker='^', color='purple', alpha=0.8)
plt.plot(range(1,nums+1), test_accs_cnn_nums_outer*100, label='Random', marker='^', color='pink', alpha=0.8)
plt.plot(range(1,nums+1), test_accs_cnn_nums_random*100, label='Fix', marker='^', color='yellow', alpha=0.8)
plt.xlabel('Number of Objects', **font_properties_labels)
plt.ylabel('Accuracy (%)', **font_properties_labels)
plt.title('Test Accuracy vs Distribution of Objects', **font_properties_title)
# Set x-axis ticks to only show integers
ax2.xaxis.set_major_locator(MaxNLocator(integer=True))
plt.legend(title='Distribution', title_fontproperties=serif_font_legend, prop=serif_font_legend)
# Set larger font size for tick labels
ax2.tick_params(axis='both', which='major', labelsize=14, labelcolor='black', labelfontfamily='serif')  # Set tick label size for both axes
plt.grid(color='gray', linestyle='--', linewidth=0.5, alpha=0.7)  # Grid with transparency
plt.tight_layout()  # Adjust layout to make it look better
plt.savefig('/project_cnn/exp_4/acc.png', bbox_inches='tight')
plt.show()

# USE 10-MINUTE TIMER TO REMIND EXP JOURNAL!
# USE 10-MINUTE TIMER TO REMIND EXP JOURNAL!
# USE 10-MINUTE TIMER TO REMIND EXP JOURNAL!
# USE 10-MINUTE TIMER TO REMIND EXP JOURNAL!
# USE 10-MINUTE TIMER TO REMIND EXP JOURNAL!
# USE 10-MINUTE TIMER TO REMIND EXP JOURNAL!
# USE 10-MINUTE TIMER TO REMIND EXP JOURNAL!
# USE 10-MINUTE TIMER TO REMIND EXP JOURNAL!
# USE 10-MINUTE TIMER TO REMIND EXP JOURNAL!
# USE 10-MINUTE TIMER TO REMIND EXP JOURNAL!
# USE 10-MINUTE TIMER TO REMIND EXP JOURNAL!
# USE 10-MINUTE TIMER TO REMIND EXP JOURNAL!




# # Font properties
# font_properties_title = {'fontsize': 20, 'fontweight': 'normal', 'fontname': 'serif'}
# font_properties_labels = {'fontsize': 18, 'fontweight': 'normal', 'fontname': 'serif'}

# # Create FontProperties for serif font
# serif_font = FontProperties(family='serif', size=16)

# # Plot for Train and Test Loss
# # plt.figure(figsize=(8, 6))
# _, ax1 = plt.subplots(figsize=(8, 6))
# ax1.set_facecolor('#F0F8FF')  # Set the axes background color to a blue shade
# plt.plot(alphas, train_losses_cnn_alpha, label='Train', marker='o', color='blue', alpha=0.8)
# plt.plot(alphas, test_losses_cnn_alpha, label='Test', marker='s', color='orange', alpha=0.8)
# # Fill between for standard deviations
# plt.fill_between(alphas, 
#                  train_losses_cnn_alpha - 1*train_losses_cnn_alpha_std, 
#                  train_losses_cnn_alpha + 1*train_losses_cnn_alpha_std, 
#                  color='blue', alpha=0.2)  # Transparent fill for train loss std

# plt.fill_between(alphas, 
#                  test_losses_cnn_alpha - 1*test_losses_cnn_alpha_std, 
#                  test_losses_cnn_alpha + 1*test_losses_cnn_alpha_std, 
#                  color='orange', alpha=0.2)  # Transparent fill for test loss std
# plt.xlabel('α', **font_properties_labels)
# plt.ylabel('Loss', **font_properties_labels)
# plt.title('Loss Values vs α', **font_properties_title)
# plt.legend(fontsize=16, prop=serif_font)
# # Set larger font size for tick labels
# ax1.tick_params(axis='both', which='major', labelsize=14, labelcolor='black', labelfontfamily='serif')  # Set tick label size for both axes
# plt.grid(color='gray', linestyle='--', linewidth=0.5, alpha=0.7)  # Grid with transparency
# plt.tight_layout()  # Adjust layout to make it look better
# # Save the figure with tight layout
# plt.savefig('/project_cnn/exp_4/loss.png', bbox_inches='tight')
# plt.show()



# # Plot for Test Accuracy
# _, ax2 = plt.subplots(figsize=(8, 6))
# ax2.set_facecolor('#F0F8FF')  # Set the axes background color to a blue shade
# plt.plot(alphas, test_accs_cnn_alpha, label='Test', marker='^', color='orange', alpha=0.8)
# plt.fill_between(alphas, 
#                  test_accs_cnn_alpha - 1*test_accs_cnn_alpha_std, 
#                  test_accs_cnn_alpha + 1*test_accs_cnn_alpha_std, 
#                  color='orange', alpha=0.2)  # Transparent fill for train loss std
# plt.xlabel('α', **font_properties_labels)
# plt.ylabel('Accuracy', **font_properties_labels)
# plt.title('Test Accuracy vs α', **font_properties_title)
# plt.legend(fontsize=16, prop=serif_font)
# # Set larger font size for tick labels
# ax2.tick_params(axis='both', which='major', labelsize=14, labelcolor='black', labelfontfamily='serif')  # Set tick label size for both axes
# plt.grid(color='gray', linestyle='--', linewidth=0.5, alpha=0.7)  # Grid with transparency
# plt.tight_layout()  # Adjust layout to make it look better
# # Save the figure with tight layout
# plt.savefig('/project_cnn/exp_4/acc.png', bbox_inches='tight')
# plt.show()