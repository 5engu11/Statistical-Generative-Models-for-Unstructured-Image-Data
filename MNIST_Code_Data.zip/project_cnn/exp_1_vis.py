import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
import pickle
import numpy as np
from matplotlib.font_manager import FontProperties

# Load all the pickle data
pkl_data = []
for seed_idx in range(10):
    # Step 1: Open the pickle file in read-binary mode
    with open(f'/project_cnn/exp_1_run={seed_idx}.pkl', 'rb') as file:
        # Step 2: Load the data from the file
        data = pickle.load(file)
    pkl_data.append(data)

# Define similar alphas
alphas = [0.002, 0.008, 0.017, 0.030, 0.045, 0.067, 0.092, 0.119, 0.149]  #[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

# Load the loss and accuracy values
train_losses_cnn_alpha_all=[]
test_losses_cnn_alpha_all=[]
test_accs_cnn_alpha_all=[]

for seed_idx in range(10):
    train_losses_cnn_alpha_seed = []
    test_losses_cnn_alpha_seed = []
    test_accs_cnn_alpha_seed = []
    for j in range(len(alphas)):
        train_losses_cnn_alpha_seed.append(pkl_data[seed_idx]["train_losses_cnn_list"][j][-1])
        test_losses_cnn_alpha_seed.append(pkl_data[seed_idx]["test_losses_cnn_list"][j][-1])
        test_accs_cnn_alpha_seed.append(pkl_data[seed_idx]["test_accs_cnn_list"][j][-1])
    train_losses_cnn_alpha_all.append(train_losses_cnn_alpha_seed)
    test_losses_cnn_alpha_all.append(test_losses_cnn_alpha_seed)
    test_accs_cnn_alpha_all.append(test_accs_cnn_alpha_seed)

# Get the mean and standard deviation per run
train_losses_cnn_alpha=np.array(train_losses_cnn_alpha_all).mean(0)
test_losses_cnn_alpha=np.array(test_losses_cnn_alpha_all).mean(0)
test_accs_cnn_alpha=np.array(test_accs_cnn_alpha_all).mean(0)

train_losses_cnn_alpha_std=np.array(train_losses_cnn_alpha_all).std(0)
test_losses_cnn_alpha_std=np.array(test_losses_cnn_alpha_all).std(0)
test_accs_cnn_alpha_std=np.array(test_accs_cnn_alpha_all).std(0)

# # Perform the plotting
# # Font properties
# font_properties_title = {'fontsize': 20, 'fontweight': 'normal', 'fontname': 'serif'}
# font_properties_labels = {'fontsize': 18, 'fontweight': 'normal', 'fontname': 'serif'}

# # Create FontProperties for serif font
# serif_font = FontProperties(family='serif', size=16)

# # Plot for Train and Test Loss
# # plt.figure(figsize=(8, 6))
# _, ax1 = plt.subplots(figsize=(8, 6))
# ax1.set_facecolor('#F0F8FF')  # Set the axes background color to a blue shade
# plt.plot(alphas, train_losses_cnn_alpha, label='Train', marker='o', color='blue', alpha=0.8)
# plt.plot(alphas, test_losses_cnn_alpha, label='Test', marker='s', color='orange', alpha=0.8)
# # Fill between for standard deviations
# plt.fill_between(alphas, 
#                  train_losses_cnn_alpha - 1*train_losses_cnn_alpha_std, 
#                  train_losses_cnn_alpha + 1*train_losses_cnn_alpha_std, 
#                  color='blue', alpha=0.2)  # Transparent fill for train loss std

# plt.fill_between(alphas, 
#                  test_losses_cnn_alpha - 1*test_losses_cnn_alpha_std, 
#                  test_losses_cnn_alpha + 1*test_losses_cnn_alpha_std, 
#                  color='orange', alpha=0.2)  # Transparent fill for test loss std
# plt.xlabel('α', **font_properties_labels)
# plt.ylabel('Loss', **font_properties_labels)
# plt.title('Loss Values vs α', **font_properties_title)
# plt.legend(fontsize=16, prop=serif_font)
# # Set larger font size for tick labels
# ax1.tick_params(axis='both', which='major', labelsize=14, labelcolor='black', labelfontfamily='serif')  # Set tick label size for both axes
# plt.grid(color='gray', linestyle='--', linewidth=0.5, alpha=0.7)  # Grid with transparency
# plt.tight_layout()  # Adjust layout to make it look better
# # Save the figure with tight layout
# plt.savefig('/project_cnn/exp_1/loss.png', bbox_inches='tight')
# plt.show()



# # Plot for Test Accuracy
# _, ax2 = plt.subplots(figsize=(8, 6))
# ax2.set_facecolor('#F0F8FF')  # Set the axes background color to a blue shade
# plt.plot(alphas, test_accs_cnn_alpha*100, label='Test', marker='^', color='orange', alpha=0.8)
# plt.fill_between(alphas, 
#                  test_accs_cnn_alpha*100 - 1*test_accs_cnn_alpha_std*100, 
#                  test_accs_cnn_alpha*100 + 1*test_accs_cnn_alpha_std*100, 
#                  color='orange', alpha=0.2)  # Transparent fill for train loss std
# plt.xlabel('α', **font_properties_labels)
# plt.ylabel('Accuracy (in %)', **font_properties_labels)
# plt.title('Test Accuracy vs α', **font_properties_title)
# plt.legend(fontsize=16, prop=serif_font)
# # Set larger font size for tick labels
# ax2.tick_params(axis='both', which='major', labelsize=14, labelcolor='black', labelfontfamily='serif')  # Set tick label size for both axes
# plt.grid(color='gray', linestyle='--', linewidth=0.5, alpha=0.7)  # Grid with transparency
# plt.tight_layout()  # Adjust layout to make it look better
# # Save the figure with tight layout
# plt.savefig('/project_cnn/exp_1/acc.png', bbox_inches='tight')
# plt.show()



# TWIN PLOTTING
# Perform the plotting
# Font properties
font_properties_title = {'fontsize': 20, 'fontweight': 'normal', 'fontname': 'serif'}
font_properties_labels = {'fontsize': 18, 'fontweight': 'normal', 'fontname': 'serif'}

# Create FontProperties for serif font
serif_font = FontProperties(family='serif', size=16)

# Create a new figure
fig, ax1 = plt.subplots(figsize=(8, 6))

# Set the axes background color to a blue shade
ax1.set_facecolor('#F0F8FF')

# Plot for Train and Test Loss
ax1.plot(alphas, train_losses_cnn_alpha, label='Train Loss', marker='o', color='blue', alpha=0.8)
ax1.plot(alphas, test_losses_cnn_alpha, label='Test Loss', marker='s', color='orange', alpha=0.8)

# Fill between for standard deviations
ax1.fill_between(alphas, 
                 train_losses_cnn_alpha - 1*train_losses_cnn_alpha_std, 
                 train_losses_cnn_alpha + 1*train_losses_cnn_alpha_std, 
                 color='blue', alpha=0.2)  # Transparent fill for train loss std

ax1.fill_between(alphas, 
                 test_losses_cnn_alpha - 1*test_losses_cnn_alpha_std, 
                 test_losses_cnn_alpha + 1*test_losses_cnn_alpha_std, 
                 color='orange', alpha=0.2)  # Transparent fill for test loss std

ax1.set_xlabel('β', **font_properties_labels)
ax1.set_ylabel('Loss', **font_properties_labels)
ax1.tick_params(axis='y', which='major', labelsize=14, labelcolor='black', labelfontfamily='serif')  # Set tick label size for loss axis
ax1.tick_params(axis='x', which='major', labelsize=14, labelcolor='black', labelfontfamily='serif')

# Create a twin y-axis for accuracy
ax2 = ax1.twinx()

# Plot for Test Accuracy
ax2.plot(alphas, test_accs_cnn_alpha*100, label='Test Accuracy', marker='^', color='green', alpha=0.8)
ax2.fill_between(alphas, 
                 test_accs_cnn_alpha*100 - 1*test_accs_cnn_alpha_std*100, 
                 test_accs_cnn_alpha*100 + 1*test_accs_cnn_alpha_std*100, 
                 color='green', alpha=0.2)  # Transparent fill for accuracy std

ax2.set_ylabel('Accuracy (%)', **font_properties_labels, rotation=270, labelpad=20)
ax2.tick_params(axis='both', which='major', labelsize=14, labelfontfamily='serif')  # Set tick label size for accuracy axis

# Set title and legend
plt.title('Loss and Accuracy vs β', **font_properties_title)
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
# ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=16, prop=serif_font)
ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=16, prop=serif_font, loc='right', bbox_to_anchor=(1, 0.50))

# Grid and tight layout
ax1.grid(color='gray', linestyle='--', linewidth=0.5, alpha=0.7)  # Grid with transparency
plt.tight_layout()  # Adjust layout to make it look better

# Save the figure with tight layout
plt.savefig('/project_cnn/exp_1/loss_acc.png', bbox_inches='tight')
plt.show()

