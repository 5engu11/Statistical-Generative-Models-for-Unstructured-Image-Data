import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
import pickle
import numpy as np
from matplotlib.font_manager import FontProperties
from matplotlib.ticker import MaxNLocator
                    
# Load all the pickle data
pkl_data = []
for seed_idx in range(10):
    # Step 1: Open the pickle file in read-binary mode
    with open(f'/project_cnn/exp_3_run={seed_idx}.pkl', 'rb') as file:
        # Step 2: Load the data from the file
        data = pickle.load(file)
    pkl_data.append(data)

nums = 5

# Load the loss and accuracy values
train_losses_cnn_nums_div0_all=[]
test_losses_cnn_nums_div0_all=[]
test_accs_cnn_nums_div0_all=[]
train_losses_cnn_nums_div_all=[]
test_losses_cnn_nums_div_all=[]
test_accs_cnn_nums_div_all=[]

for seed_idx in range(10):
    train_losses_cnn_nums_div0_seed = []
    test_losses_cnn_nums_div0_seed = []
    test_accs_cnn_nums_div0_seed = []
    train_losses_cnn_nums_div_seed = []
    test_losses_cnn_nums_div_seed = []
    test_accs_cnn_nums_div_seed = []
    for j in range(nums):
        train_losses_cnn_nums_div0_seed.append(pkl_data[seed_idx]["train_losses_cnn_list_div0"][j][-1])
        test_losses_cnn_nums_div0_seed.append(pkl_data[seed_idx]["test_losses_cnn_list_div0"][j][-1])
        test_accs_cnn_nums_div0_seed.append(pkl_data[seed_idx]["test_accs_cnn_list_div0"][j][-1])
        train_losses_cnn_nums_div_seed.append(pkl_data[seed_idx]["train_losses_cnn_list_div"][j][-1])
        test_losses_cnn_nums_div_seed.append(pkl_data[seed_idx]["test_losses_cnn_list_div"][j][-1])
        test_accs_cnn_nums_div_seed.append(pkl_data[seed_idx]["test_accs_cnn_list_div"][j][-1])
    train_losses_cnn_nums_div0_all.append(train_losses_cnn_nums_div0_seed)
    test_losses_cnn_nums_div0_all.append(test_losses_cnn_nums_div0_seed)
    test_accs_cnn_nums_div0_all.append(test_accs_cnn_nums_div0_seed)
    train_losses_cnn_nums_div_all.append(train_losses_cnn_nums_div_seed)
    test_losses_cnn_nums_div_all.append(test_losses_cnn_nums_div_seed)
    test_accs_cnn_nums_div_all.append(test_accs_cnn_nums_div_seed)

# Get the mean and standard deviation per run
train_losses_cnn_nums_div0=np.array(train_losses_cnn_nums_div0_all).mean(0)
test_losses_cnn_nums_div0=np.array(test_losses_cnn_nums_div0_all).mean(0)
test_accs_cnn_nums_div0=np.array(test_accs_cnn_nums_div0_all).mean(0)

train_losses_cnn_nums_div0_std=np.array(train_losses_cnn_nums_div0_all).std(0)
test_losses_cnn_nums_div0_std=np.array(test_losses_cnn_nums_div0_all).std(0)
test_accs_cnn_nums_div0_std=np.array(test_accs_cnn_nums_div0_all).std(0)

train_losses_cnn_nums_div=np.array(train_losses_cnn_nums_div_all).mean(0)
test_losses_cnn_nums_div=np.array(test_losses_cnn_nums_div_all).mean(0)
test_accs_cnn_nums_div=np.array(test_accs_cnn_nums_div_all).mean(0)

train_losses_cnn_nums_div_std=np.array(train_losses_cnn_nums_div_all).std(0)
test_losses_cnn_nums_div_std=np.array(test_losses_cnn_nums_div_all).std(0)
test_accs_cnn_nums_div_std=np.array(test_accs_cnn_nums_div_all).std(0)






# Font properties
font_properties_title = {'fontsize': 20, 'fontweight': 'normal', 'fontname': 'serif'}
font_properties_labels = {'fontsize': 18, 'fontweight': 'normal', 'fontname': 'serif'}

from matplotlib.font_manager import FontProperties

# Create FontProperties for serif font
serif_font = FontProperties(family='serif', size=16)



_, ax1 = plt.subplots(figsize=(8, 6))
ax1.set_facecolor('#F0F8FF')  # Set the axes background color to a blue shade
plt.plot(range(1, nums+1), train_losses_cnn_nums_div0*100, label='Train', marker='o', color='blue', alpha=0.8)
plt.plot(range(1, nums+1), train_losses_cnn_nums_div, label='Train - Shuffled', marker='o', color='#ADD8E6', alpha=0.8)
plt.plot(range(1, nums+1), test_losses_cnn_nums_div0*100, label='Test', marker='s', color='orange', alpha=0.8)
plt.plot(range(1, nums+1), test_losses_cnn_nums_div, label='Test - Shuffled', marker='s', color='#FFA07A', alpha=0.8)
plt.fill_between(range(1, nums+1), 
                 train_losses_cnn_nums_div0*100 - 1*train_losses_cnn_nums_div0_std*100, 
                 train_losses_cnn_nums_div0*100 + 1*train_losses_cnn_nums_div0_std*100, 
                 color='blue', alpha=0.2)  # Transparent fill for test loss std
plt.fill_between(range(1, nums+1), 
                 train_losses_cnn_nums_div - 1*train_losses_cnn_nums_div_std, 
                 train_losses_cnn_nums_div + 1*train_losses_cnn_nums_div_std, 
                 color='#ADD8E6', alpha=0.2)  # Transparent fill for test loss std
plt.fill_between(range(1, nums+1), 
                 test_losses_cnn_nums_div0*100 - 1*test_losses_cnn_nums_div0_std*100, 
                 test_losses_cnn_nums_div0*100 + 1*test_losses_cnn_nums_div0_std*100, 
                 color='orange', alpha=0.2)  # Transparent fill for test loss std
plt.fill_between(range(1, nums+1), 
                 test_losses_cnn_nums_div - 1*test_losses_cnn_nums_div_std, 
                 test_losses_cnn_nums_div + 1*test_losses_cnn_nums_div_std, 
                 color='#FFA07A', alpha=0.2)  # Transparent fill for test loss std
plt.xlabel('Number of Objects', **font_properties_labels)
plt.ylabel('Loss', **font_properties_labels)
plt.title('Loss Values vs Number of Objects', **font_properties_title)
ax1.xaxis.set_major_locator(MaxNLocator(integer=True))
plt.legend(fontsize=16, prop=serif_font)
# Set larger font size for tick labels
ax1.tick_params(axis='both', which='major', labelsize=14, labelcolor='black', labelfontfamily='serif')  # Set tick label size for both axes
plt.grid(color='gray', linestyle='--', linewidth=0.5, alpha=0.7)  # Grid with transparency
plt.tight_layout()  # Adjust layout to make it look better
plt.savefig('/project_cnn/exp_3/loss.png', bbox_inches='tight')
plt.show()

# Plot for Test Accuracy
_, ax2 = plt.subplots(figsize=(8, 6))
ax2.set_facecolor('#F0F8FF')  # Set the axes background color to a blue shade
plt.plot(range(1, nums+1), test_accs_cnn_nums_div0*100, label='Test', marker='^', color='orange', alpha=0.8)
plt.plot(range(1, nums+1), test_accs_cnn_nums_div*100, label='Test - Shuffled', marker='^', color='#FFA07A', alpha=0.8)
plt.fill_between(range(1, nums+1), 
                 test_accs_cnn_nums_div0*100 - 1*test_accs_cnn_nums_div0_std*100, 
                 test_accs_cnn_nums_div0*100 + 1*test_accs_cnn_nums_div0_std*100, 
                 color='orange', alpha=0.2)  # Transparent fill for test loss std
plt.fill_between(range(1, nums+1), 
                 test_accs_cnn_nums_div*100 - 1*test_accs_cnn_nums_div_std*100, 
                 test_accs_cnn_nums_div*100 + 1*test_accs_cnn_nums_div_std*100, 
                 color='#FFA07A', alpha=0.2)  # Transparent fill for test loss std
plt.xlabel('Number of Objects', **font_properties_labels)
plt.ylabel('Accuracy (in %)', **font_properties_labels)
plt.title('Test Accuracy vs Number of Objects', **font_properties_title)
ax2.xaxis.set_major_locator(MaxNLocator(integer=True))
plt.legend(fontsize=16, prop=serif_font)
# Set larger font size for tick labels
ax2.tick_params(axis='both', which='major', labelsize=14, labelcolor='black', labelfontfamily='serif')  # Set tick label size for both axes
plt.grid(color='gray', linestyle='--', linewidth=0.5, alpha=0.7)  # Grid with transparency
plt.tight_layout()  # Adjust layout to make it look better
plt.savefig('/project_cnn/exp_3/acc.png', bbox_inches='tight')
plt.show()