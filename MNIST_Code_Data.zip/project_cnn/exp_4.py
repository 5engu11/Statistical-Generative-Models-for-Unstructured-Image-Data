import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
import numpy as np
import matplotlib.pyplot as plt
import torch.optim as optim
import torch.nn.functional as F
from tqdm import tqdm
from datetime import datetime

path = '/project_cnn/exp_4_'  + '.txt'

class CNNNet(nn.Module):
    def __init__(self, input_size, num_classes):
        super(CNNNet, self).__init__()
        self.input_size = input_size
        self.conv1 = nn.Conv2d(1, 16, 3, padding=1)
        self.pool = nn.MaxPool2d(2)
        self.conv2 = nn.Conv2d(16, 32, 3, padding=1)
        self.fc = nn.Linear(32 * int(self.input_size/4) * int(self.input_size/4), num_classes)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = self.pool(x)
        x = F.relu(self.conv2(x))
        x = self.pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x

def print_tf(text):
    with open(path, 'a') as file:
        file.write(text)
def scale_image(image, alpha):
    scale_transform = transforms.RandomAffine(degrees=0, scale=(alpha, alpha))
    scaled_image = scale_transform(image)
    return scaled_image

def replicate_image_(images, alpha, num, div="diag"):
    scaled_images = []
    scale_transform = transforms.RandomAffine(degrees=0, scale=(alpha, alpha))
    margin_factor = 2.75
    # 缩放图像
    trans_images = scale_transform(images)
    for i in range(images.size(0)):
        scaled_image = trans_images[i]
        # 创建空的图像
        layered_img = np.zeros_like(scaled_image)
        for j in range(num):
            if div=="random":
              # 生成随机平移量
              dx = np.random.randint(-int(images.size(2)/margin_factor), int(images.size(2)/margin_factor))
              dy = np.random.randint(-int(images.size(2)/margin_factor), int(images.size(2)/margin_factor))
            if div=="diag":
              # 生成固定平移量
              stepsize= int(images.size(2))
              dx = -int(images.size(2)/2) + int(stepsize*(j+1)/(num+1))
              dy = -int(images.size(2)/2) + int(stepsize*(j+1)/(num+1))
            if div=="left":
              # 生成固定平移量
              stepsize= int(images.size(2))
              dx = -int(images.size(2)/2) + int(stepsize*(j+1)/(num+1))
              dy = -int(images.size(2)/4)
            if div=="inner":
              # 生成较小随机平移量
              dx = np.random.randint(-int(images.size(2)/8), int(images.size(2)/8))
              dy = np.random.randint(-int(images.size(2)/8), int(images.size(2)/8))
            if div=="outer":
              ind_x = np.random.binomial(1, 0.5, 1);
              ind_y = np.random.binomial(1, 0.5, 1)
              # 生成较大随机平移量
              dx_1 = np.random.randint(-int(images.size(2)/2), -int(images.size(2)/4));dx_2 = np.random.randint(int(images.size(2)/4), int(images.size(2)/2))
              dx= int(ind_x*dx_1+(1-ind_x)*dx_2)
              dy_1 = np.random.randint(-int(images.size(2)/2), -int(images.size(2)/4));dy_2 = np.random.randint(int(images.size(2)/4), int(images.size(2)/2))
              dy= int(ind_y*dy_1+(1-ind_y)*dy_2)
            if div=="fix":
              # 生成固定平移量
              dx = int(0)
              dy = int(0)
            
            #平移图像
            shifted_image = np.roll(scaled_image, shift=(dx, dy), axis=(1, 2))
            # 将平移的图像叠加到图层
            layered_img[shifted_image > 0] = shifted_image[shifted_image > 0]
        scaled_images.append(torch.Tensor(layered_img))
    scaled_images = torch.stack(scaled_images)
    return scaled_images

# 定义训练函数
def train_(model, train_loader, test_loader, criterion, optimizer, alpha, num, num_epochs, device, div='diag'):
    model.train()
    train_losses = []
    test_losses = []
    test_accs = []
    for epoch in range(num_epochs):
        running_loss = 0.0
        correct = 0
        total = 0
        for images, labels in tqdm(train_loader):
          
            images = replicate_image_(images, alpha, num, div)
            images = images.to(device); labels=labels.to(device)
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            running_loss += loss.item() #* images.size(0)

        epoch_loss = running_loss / len(train_loader.dataset)
        epoch_acc = correct / total
        train_losses.append(epoch_loss)

        # 在测试集上评估模型性能
        test_loss, test_acc = evaluate_(model, test_loader, criterion, alpha, num, device, div)
        test_losses.append(test_loss)
        test_accs.append(test_acc)
        print_tf(f"Epoch {epoch+1}/{num_epochs} - Train Loss: {epoch_loss:.4f} - Train Accuracy: {epoch_acc:.4f} - Test Loss: {test_loss:.4f} - Test Accuracy: {test_acc:.4f} \n")

    # 绘制训练误差和测试误差曲线
    # if num_epochs>1:
    #   plot_losses(train_losses, test_losses, test_accs);
    return train_losses, test_losses, test_accs

# 定义评估函数
def evaluate_(model, dataloader,criterion, alpha ,num, device, div='diag'):
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0
    with torch.no_grad():
        for images, labels in dataloader:
            images = replicate_image_(images, alpha, num, div)
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)

            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            running_loss += loss.item() # * images.size(0)

    loss = running_loss / len(dataloader.dataset)
    accuracy = correct / total
    return loss, accuracy

# 定义绘制损失曲线的函数
def plot_losses(train_losses, test_losses, test_accs ):
    plt.figure()
    plt.plot(train_losses, label='Train Loss')
    plt.plot(test_losses, label='Test Loss')
    plt.plot(test_accs, label='Test Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()
    
    
if __name__ == "__main__":
    # Config
    alpha0 = 0.4; nums = 5; num_epochs = 5; num_runs = 10
    
    training, visualize_images = False, True
    
    if training:
        # Check if CUDA is available
        if torch.cuda.is_available():
            device = torch.device("cuda")           # Use the first available GPU
            print("CUDA is available. Using GPU.")
        else:
            device = torch.device("cpu")            # Fallback to CPU
            print("CUDA is not available. Using CPU.")
        
        for run_idx in range(num_runs):
            print_tf(f"\n EXPERIMENT 4 RUN = {run_idx} \n")
            # Load the MNIST dataset
            transform = transforms.Compose([transforms.ToTensor()])
            data_train = torchvision.datasets.MNIST(root='./data', train=True, transform=transform, download=True)
            data_test = torchvision.datasets.MNIST(root='./data', train=False, transform=transform, download=True)
            train_loader = torch.utils.data.DataLoader(data_train, batch_size=1024, shuffle=True)
            test_loader = torch.utils.data.DataLoader(data_test, batch_size=2048, shuffle=False)

            # 定义损失函数和优化器
            criterion = nn.CrossEntropyLoss()
            cnn_net_diag = CNNNet(28,10).to(device)
            optimizer_cnn_diag = optim.Adam(cnn_net_diag.parameters(), lr=0.001)

            cnn_net_left = CNNNet(28,10).to(device)
            optimizer_cnn_left = optim.Adam(cnn_net_left.parameters(), lr=0.001)

            cnn_net_inner = CNNNet(28,10).to(device)
            optimizer_cnn_inner = optim.Adam(cnn_net_inner.parameters(), lr=0.001)

            cnn_net_outer = CNNNet(28,10).to(device)
            optimizer_cnn_outer = optim.Adam(cnn_net_outer.parameters(), lr=0.001)

            cnn_net_random = CNNNet(28,10).to(device)
            optimizer_cnn_random = optim.Adam(cnn_net_random.parameters(), lr=0.001)

            cnn_net_fix = CNNNet(28,10).to(device)
            optimizer_cnn_fix = optim.Adam(cnn_net_fix.parameters(), lr=0.001)

            train_losses_cnn_list_diag=[];test_losses_cnn_list_diag=[];test_accs_cnn_list_diag=[]
            train_losses_cnn_list_left=[];test_losses_cnn_list_left=[];test_accs_cnn_list_left=[]
            train_losses_cnn_list_inner=[];test_losses_cnn_list_inner=[];test_accs_cnn_list_inner=[]
            train_losses_cnn_list_outer=[];test_losses_cnn_list_outer=[];test_accs_cnn_list_outer=[]
            train_losses_cnn_list_random=[];test_losses_cnn_list_random=[];test_accs_cnn_list_random=[]
            train_losses_cnn_list_fix=[];test_losses_cnn_list_fix=[];test_accs_cnn_list_fix=[]

            # 训练基于CNN的网络
            for num_obj in tqdm(range(nums)):
                print_tf(f"\n For Diagonal Pattern Data (num_obj={num_obj+1}) \n")
                train_losses_cnn_diag, test_losses_cnn_diag, test_accs_cnn_diag = train_(cnn_net_diag, train_loader, test_loader, criterion, optimizer_cnn_diag, alpha=alpha0, num=num_obj+1, num_epochs=num_epochs, device=device, div='diag')
                train_losses_cnn_list_diag.append(train_losses_cnn_diag);test_losses_cnn_list_diag.append(test_losses_cnn_diag);test_accs_cnn_list_diag.append(test_accs_cnn_diag)

                print_tf(f"\n For Left Pattern Data (num_obj={num_obj+1}) \n")
                train_losses_cnn_left, test_losses_cnn_left, test_accs_cnn_left = train_(cnn_net_left, train_loader, test_loader, criterion, optimizer_cnn_left, alpha=alpha0, num=num_obj+1, num_epochs=num_epochs, device=device, div='left')
                train_losses_cnn_list_left.append(train_losses_cnn_left);test_losses_cnn_list_left.append(test_losses_cnn_left);test_accs_cnn_list_left.append(test_accs_cnn_left)

                print_tf(f"\n For Inner Pattern Data (num_obj={num_obj+1}) \n")
                train_losses_cnn_inner, test_losses_cnn_inner, test_accs_cnn_inner = train_(cnn_net_inner, train_loader, test_loader, criterion, optimizer_cnn_inner, alpha=alpha0, num=num_obj+1, num_epochs=num_epochs, device=device, div='inner')
                train_losses_cnn_list_inner.append(train_losses_cnn_inner);test_losses_cnn_list_inner.append(test_losses_cnn_inner);test_accs_cnn_list_inner.append(test_accs_cnn_inner)

                print_tf(f"\n For Outer Pattern Data (num_obj={num_obj+1}) \n")
                train_losses_cnn_outer, test_losses_cnn_outer, test_accs_cnn_outer = train_(cnn_net_outer, train_loader, test_loader, criterion, optimizer_cnn_outer, alpha=alpha0, num=num_obj+1, num_epochs=num_epochs, device=device, div='outer')
                train_losses_cnn_list_outer.append(train_losses_cnn_outer);test_losses_cnn_list_outer.append(test_losses_cnn_outer);test_accs_cnn_list_outer.append(test_accs_cnn_outer)

                print_tf(f"\n For Random Pattern Data (num_obj={num_obj+1}) \n")
                train_losses_cnn_random, test_losses_cnn_random, test_accs_cnn_random = train_(cnn_net_random, train_loader, test_loader, criterion, optimizer_cnn_random, alpha=alpha0, num=num_obj+1, num_epochs=num_epochs, device=device, div='random')
                train_losses_cnn_list_random.append(train_losses_cnn_random);test_losses_cnn_list_random.append(test_losses_cnn_random);test_accs_cnn_list_random.append(test_accs_cnn_random)

                print_tf(f"\n For Fixed Pattern Data (num_obj={num_obj+1}) \n")
                train_losses_cnn_fix, test_losses_cnn_fix, test_accs_cnn_fix = train_(cnn_net_fix, train_loader, test_loader, criterion, optimizer_cnn_fix, alpha=alpha0, num=num_obj+1, num_epochs=num_epochs, device=device, div='fix')
                train_losses_cnn_list_fix.append(train_losses_cnn_fix);test_losses_cnn_list_fix.append(test_losses_cnn_fix);test_accs_cnn_list_fix.append(test_accs_cnn_fix)
                
            save_dict ={"train_losses_cnn_list_diag":   train_losses_cnn_list_diag,
                        "test_losses_cnn_list_diag":    test_losses_cnn_list_diag,
                        "test_accs_cnn_list_diag":      test_accs_cnn_list_diag,
                        "train_losses_cnn_list_left":   train_losses_cnn_list_left,
                        "test_losses_cnn_list_left":    test_losses_cnn_list_left,
                        "test_accs_cnn_list_left":      test_accs_cnn_list_left,
                        "train_losses_cnn_list_inner":  train_losses_cnn_list_inner,
                        "test_losses_cnn_list_inner":   test_losses_cnn_list_inner,
                        "test_accs_cnn_list_inner":     test_accs_cnn_list_inner,
                        "train_losses_cnn_list_outer":  train_losses_cnn_list_outer,
                        "test_losses_cnn_list_outer":   test_losses_cnn_list_outer,
                        "test_accs_cnn_list_outer":     test_accs_cnn_list_outer,
                        "train_losses_cnn_list_random": train_losses_cnn_list_random,
                        "test_losses_cnn_list_random":  test_losses_cnn_list_random,
                        "test_accs_cnn_list_random":    test_accs_cnn_list_random,
                        "train_losses_cnn_list_fix":    train_losses_cnn_list_fix,
                        "test_losses_cnn_list_fix":     test_losses_cnn_list_fix,
                        "test_accs_cnn_list_fix":       test_accs_cnn_list_fix
                        }
            
            import pickle
            # Save dictionary to a pickle file
            with open(f'/project_cnn/exp_4_run={run_idx}.pkl', 'wb') as f:
                pickle.dump(save_dict, f)
                
    if visualize_images:
        transform = transforms.Compose([transforms.ToTensor()])
        data_train = torchvision.datasets.MNIST(root='./data', train=True, transform=transform, download=True)
        train_loader = torch.utils.data.DataLoader(data_train, batch_size=1, shuffle=True)

        count=0; num=7; alpha=0.5
        for images, labels in train_loader:
                count=count+1
                if count>1:
                    break;
                if count<=1:
                    imagess_diag=[];imagess_random=[];imagess_inner=[];imagess_outer=[];imagess_left=[];imagess_fix=[]
                    for j in range(num):
                        imagess_diag.append(replicate_image_(images,alpha=alpha,num=j+1,div="diag"))
                        imagess_inner.append(replicate_image_(images,alpha=alpha,num=j+1,div="inner"))
                        imagess_outer.append(replicate_image_(images,alpha=alpha,num=j+1,div="outer"))
                        imagess_random.append(replicate_image_(images,alpha=alpha,num=j+1,div="random"))
                        imagess_left.append(replicate_image_(images,alpha=alpha,num=j+1,div="left"))
                        imagess_fix.append(replicate_image_(images,alpha=alpha,num=j+1,div="fix"))
                    #print(len(imagess))
                    print(images[0].shape)
                    fig, axes = plt.subplots(nrows=6, ncols=num, figsize=(7, 6), 
                                gridspec_kw={'wspace': 0.15, 'hspace': 0.15})
                    cnt = -1
                    for i in range(images.size(0)):
                        cnt += 1
                        for j in range(num):
                            axes[i+cnt, j].imshow(imagess_diag[j][i,:].squeeze().numpy(), cmap='gray')
                            axes[i+cnt, j].axis('off')
                            if i == 0 and j==0:
                                axes[i, j].set_title(f'J: {j+1}', fontsize=14)
                            elif i == 0:
                                axes[i, j].set_title(f'{j+1}', fontsize=14)
                    for i in range(images.size(0)):
                        cnt += 1
                        for j in range(num):
                            axes[i+cnt, j].imshow(imagess_left[j][i,:].squeeze().numpy(), cmap='gray')
                            axes[i+cnt, j].axis('off')
                    for i in range(images.size(0)):
                        cnt += 1
                        for j in range(num):
                            axes[i+cnt, j].imshow(imagess_inner[j][i,:].squeeze().numpy(), cmap='gray')
                            axes[i+cnt, j].axis('off')
                    for i in range(images.size(0)):
                        cnt += 1
                        for j in range(num):
                            axes[i+cnt, j].imshow(imagess_outer[j][i,:].squeeze().numpy(), cmap='gray')
                            axes[i+cnt, j].axis('off')
                    for i in range(images.size(0)):
                        cnt += 1
                        for j in range(num):
                            axes[i+cnt, j].imshow(imagess_random[j][i,:].squeeze().numpy(), cmap='gray')
                            axes[i+cnt, j].axis('off')
                    for i in range(images.size(0)):
                        cnt += 1
                        for j in range(num):
                            axes[i+cnt, j].imshow(imagess_fix[j][i,:].squeeze().numpy(), cmap='gray')
                            axes[i+cnt, j].axis('off')
                            
                        
                    
                    # Add rotated titles to each row
                    titles = ['Diagonal', 'Left', 'Inner', 'Outer', 'Random', 'Fixed']
                    for i, ax in enumerate(axes):
                        plt.text(0.12, (5 - 0.80*i - 0.02) / 6, titles[i], fontsize=10,
                                ha='right', va='center', rotation=90, transform=fig.transFigure)
                    plt.savefig('/project_cnn/exp_4/visuals.png', bbox_inches='tight')
                    plt.show()