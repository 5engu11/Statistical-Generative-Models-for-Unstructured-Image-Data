import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
import numpy as np
import matplotlib.pyplot as plt
import torch.optim as optim
import torch.nn.functional as F
from tqdm import tqdm
from datetime import datetime

path = '/project_cnn/exp_2_' + '.txt'

class CNNNet(nn.Module):
    def __init__(self, input_size, num_classes):
        super(CNNNet, self).__init__()
        self.input_size = input_size
        self.conv1 = nn.Conv2d(1, 16, 3, padding=1)
        self.pool = nn.MaxPool2d(2)
        self.conv2 = nn.Conv2d(16, 32, 3, padding=1)
        self.fc = nn.Linear(32 * int(self.input_size/4) * int(self.input_size/4), num_classes)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = self.pool(x)
        x = F.relu(self.conv2(x))
        x = self.pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x

def print_tf(text):
    with open(path, 'a') as file:
        file.write(text)
        

def scale_image(image, alpha):
    scale_transform = transforms.RandomAffine(degrees=0, scale=(alpha, alpha))
    scaled_image = scale_transform(image)
    return scaled_image

def replicate_image(images, alpha, num, shuffle=True):
    scaled_images = []
    scale_transform = transforms.RandomAffine(degrees=0, scale=(alpha, alpha))
    images = scale_transform(images)
    for i in tqdm(range(images.size(0))):
        scaled_image = images[i]
        layered_img = np.zeros_like(scaled_image)
        for j in range(num):
            if shuffle==True: 
                dx = np.random.randint(-int(images.size(2)/2.75), int(images.size(2)/2.75))
                dy = np.random.randint(-int(images.size(2)/2.75), int(images.size(2)/2.75))
            else:
                stepsize= int(images.size(2))
                dx = -int(images.size(2)/2) + int(stepsize*(j+1)/(num+1))
                dy = -int(images.size(2)/2) + int(stepsize*(j+1)/(num+1))
                
                
            shifted_image = np.roll(scaled_image, shift=(dx, dy), axis=(1, 2))
            layered_img[shifted_image > 0] = shifted_image[shifted_image > 0]
        scaled_images.append(torch.Tensor(layered_img))
    scaled_images = torch.stack(scaled_images)
    return scaled_images

def replicate_image_old(images, alpha, num, shuffle=True):
    scaled_images = []
    scale_transform = transforms.RandomAffine(degrees=0, scale=(alpha, alpha))
    images = scale_transform(images)
    rng = np.random.default_rng()
    
    for i in tqdm(range(images.size(0))):
        # import pdb; pdb.set_trace()
        scaled_image = images[i]
        # Create an empty image with the same shape as scaled_image
        layered_img = np.zeros_like(scaled_image)

        for j in range(num):
            if shuffle:
                # Generate random translation amounts
                dx = np.random.randint(-int(scaled_image.shape[2] / 2), int(scaled_image.shape[2] / 2))
                dy = np.random.randint(-int(scaled_image.shape[2] / 2), int(scaled_image.shape[2] / 2))
                # dx = rng.integers(-int(scaled_image.shape[2] / 2), int(scaled_image.shape[2] / 2))
                # dy = rng.integers(-int(scaled_image.shape[2] / 2), int(scaled_image.shape[2] / 2))
            else:
                # Generate fixed translation amounts
                stepsize = int(scaled_image.shape[2])
                dx = -int(scaled_image.shape[2] / 2) + int(stepsize * (j + 1) / (num + 1))
                dy = -int(scaled_image.shape[2] / 2) + int(stepsize * (j + 1) / (num + 1))

            # Create a shifted image without wrapping around
            shifted_image = np.zeros_like(scaled_image)

            # Shift right or left
            if dx > 0:  # Shift right
                shifted_image[:, :, dx:] = scaled_image[:, :, :-dx]
            elif dx < 0:  # Shift left
                shifted_image[:, :, :dx] = scaled_image[:, :, -dx:]

            # Shift down or up
            if dy > 0:  # Shift down
                shifted_image[:, dy:, :] = scaled_image[:, :-dy, :]
            elif dy < 0:  # Shift up
                shifted_image[:, :dy, :] = scaled_image[:, -dy:, :]

            # Overlay the shifted image onto the layered image
            layered_img[shifted_image > 0] = shifted_image[shifted_image > 0]

        scaled_images.append(torch.Tensor(layered_img))

    scaled_images = torch.stack(scaled_images)
    return scaled_images

def train1(model, train_loader, test_loader, criterion, optimizer, alpha, num, num_epochs, device, shuffle=True):
    model.train()
    train_losses = []
    test_losses = []
    test_accs = []
    for epoch in range(num_epochs):
        running_loss = 0.0
        correct = 0
        total = 0
        for images, labels in train_loader:
            images = replicate_image(images, alpha, num, shuffle)
            images, labels = images.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            running_loss += loss.item()         #* images.size(0)

        epoch_loss = running_loss / len(train_loader.dataset)
        epoch_acc = correct / total
        train_losses.append(epoch_loss)

        test_loss, test_acc = evaluate1(model, test_loader, criterion, alpha, num, device, shuffle)
        test_losses.append(test_loss)
        test_accs.append(test_acc)
        print_tf(f"Epoch {epoch+1}/{num_epochs} - Train Loss: {epoch_loss:.4f} - Train Accuracy: {epoch_acc:.4f} - Test Loss: {test_loss:.4f} - Test Accuracy: {test_acc:.4f} \n")

    return train_losses, test_losses, test_accs


def evaluate1(model, dataloader,criterion, alpha ,num, device, shuffle=True):
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0
    with torch.no_grad():
        for images, labels in dataloader:
            images = replicate_image(images, alpha, num, shuffle)
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)

            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            running_loss += loss.item()         #* images.size(0)

    loss = running_loss / len(dataloader.dataset)
    accuracy = correct / total
    return loss, accuracy

def plot_losses(train_losses, test_losses, test_accs ):
    plt.figure()
    plt.plot(train_losses, label='Train Loss')
    plt.plot(test_losses, label='Test Loss')
    plt.plot(test_accs, label='Test Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()


if __name__ == "__main__":
    # import pdb; pdb.set_trace()
    # Config
    alpha0 = 0.3; nums = 5; num_runs = 10; num_epochs=5
    print(f"alpha = {alpha0}; nums = {nums}; num_epoch = {num_epochs}")
    
    training, visualize_images, calc_beta = False, True, False
    
    if training:
        # Check if CUDA is available
        if torch.cuda.is_available():
            device = torch.device("cuda")           # Use the first available GPU
            print("CUDA is available. Using GPU.")
        else:
            device = torch.device("cpu")            # Fallback to CPU
            print("CUDA is not available. Using CPU.")
        
        for run_idx in range(num_runs):
            print_tf(f"\n EXPERIMENT 2 RUN = {run_idx} \n")    
        
            # Load the MNIST dataset
            transform = transforms.Compose([transforms.ToTensor()])
            data_train = torchvision.datasets.MNIST(root='./data', train=True, transform=transform, download=True)
            data_test = torchvision.datasets.MNIST(root='./data', train=False, transform=transform, download=True)
            train_loader = torch.utils.data.DataLoader(data_train, batch_size=1024, shuffle=True)
            test_loader = torch.utils.data.DataLoader(data_test, batch_size=2048, shuffle=False)

            # 定义损失函数和优化器
            criterion = nn.CrossEntropyLoss()
            cnn_net1 = CNNNet(28,10).to(device)
            optimizer_cnn1 = optim.Adam(cnn_net1.parameters(), lr=0.001)

            
            train_losses_cnn_list1=[]
            test_losses_cnn_list1=[]
            test_accs_cnn_list1=[]

           
            for j in tqdm(range(nums)):
                print_tf(f"\n num_obj={j+1} \n")
                train_losses_cnn1, test_losses_cnn1, test_accs_cnn1 = train1(cnn_net1, train_loader, test_loader, criterion, optimizer_cnn1, alpha=alpha0, num=j+1, num_epochs=num_epochs, device=device)
                train_losses_cnn_list1.append(train_losses_cnn1)
                test_losses_cnn_list1.append(test_losses_cnn1)
                test_accs_cnn_list1.append(test_accs_cnn1)
                
            save_dict ={"train_losses_cnn_list1":   train_losses_cnn_list1,
                        "test_losses_cnn_list1":    test_losses_cnn_list1,
                        "test_accs_cnn_list1":      test_accs_cnn_list1,
                        }
            
            import pickle
            # Save dictionary to a pickle file
            with open(f'/project_cnn/exp_2_run={run_idx}.pkl', 'wb') as f:
                pickle.dump(save_dict, f)
                
    if visualize_images:
        transform = transforms.Compose([transforms.ToTensor()])
        data_train = torchvision.datasets.MNIST(root='./data', train=True, transform=transform, download=True)
        train_loader = torch.utils.data.DataLoader(data_train, batch_size=5, shuffle=True)

        count=0; num=7; alpha=0.5
        for images, labels in train_loader:
            count += 1
            if count>1:
                break;
            if count<=1:
                imagess=[]
                for j in range(num):
                    imagess.append(replicate_image(images, alpha=alpha, num=j+1))
                print(len(imagess))
                print(imagess[0].shape)
                # Visualize scaled images
                fig, axes = plt.subplots(nrows=5, ncols=num, figsize=(num, 5), 
                                gridspec_kw={'wspace': 0.15, 'hspace': 0.15})
                for i in range(images.size(0)):
                    for j in range(num):
                        # Get the image data
                        obj = imagess[j][i].squeeze().numpy()  # Ensure correct indexing
                        
                        # Use the correct axes index
                        axes[i, j].imshow(obj, cmap='gray')  # Access axes with [i, j]
                        axes[i, j].axis('off')  # Turn off axis
                        if i == 0 and j==0:
                            axes[i, j].set_title(f' J: {j+1}', fontsize=18)
                        elif i == 0:
                            axes[i, j].set_title(f'{j+1}', fontsize=18)
                
                # Adjust layout to minimize gaps
                # plt.subplots_adjust(hspace=0)  # Set vertical spacing to zero
                # plt.tight_layout()  # Automatically adjust subplot parameters
                plt.savefig('/project_cnn/exp_2/visuals.png', bbox_inches='tight')
                plt.show()