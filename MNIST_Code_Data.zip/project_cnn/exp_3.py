import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
import numpy as np
import matplotlib.pyplot as plt
import torch.optim as optim
import torch.nn.functional as F

from tqdm import tqdm
from datetime import datetime

path = '/project_cnn/exp_3_'  + '.txt'


class CNNNet(nn.Module):
    def __init__(self, input_size, num_classes):
        super(CNNNet, self).__init__()
        self.input_size = input_size
        self.conv1 = nn.Conv2d(1, 16, 3, padding=1)
        self.pool = nn.MaxPool2d(2)
        self.conv2 = nn.Conv2d(16, 32, 3, padding=1)
        self.fc = nn.Linear(32 * int(self.input_size/4) * int(self.input_size/4), num_classes)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = self.pool(x)
        x = F.relu(self.conv2(x))
        x = self.pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x

def print_tf(text):
    with open(path, 'a') as file:
        file.write(text)
        
def scale_image(image, alpha):
    scale_transform = transforms.RandomAffine(degrees=0, scale=(alpha, alpha))
    scaled_image = scale_transform(image)
    return scaled_image

def replicate_image(images, alpha, num, shuffle=True):
    scaled_images = []
    scale_transform = transforms.RandomAffine(degrees=0, scale=(alpha, alpha))
    scaled_image = scale_transform(images)
    for i in tqdm(range(images.size(0))):
        
        scaled_image = images[i]
        layered_img = np.zeros_like(scaled_image)
        for j in range(num):
            if shuffle==True: 
                dx = np.random.randint(-int(images.size(2)/2), int(images.size(2)/2))
                dy = np.random.randint(-int(images.size(2)/2), int(images.size(2)/2))
            else:
                stepsize= int(images.size(2))
                dx = -int(images.size(2)/2) + int(stepsize*(j+1)/(num+1))
                dy = -int(images.size(2)/2) + int(stepsize*(j+1)/(num+1))
                
            shifted_image = np.roll(scaled_image, shift=(dx, dy), axis=(1, 2))
            
            layered_img[shifted_image > 0] = shifted_image[shifted_image > 0]
        scaled_images.append(torch.Tensor(layered_img))
    scaled_images = torch.stack(scaled_images)
    return scaled_images


def train1(model, train_loader, test_loader, criterion, optimizer, alpha, num, num_epochs, device, shuffle=True):
    model.train()
    train_losses = []
    test_losses = []
    test_accs = []
    
    for epoch in range(num_epochs):
        running_loss = 0.0
        correct = 0
        total = 0
        for images, labels in train_loader:
            images = replicate_image(images, alpha, num, shuffle)
            images, labels = images.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            running_loss += loss.item() #* images.size(0)

        epoch_loss = running_loss / len(train_loader.dataset)
        epoch_acc = correct / total
        train_losses.append(epoch_loss)

        
        test_loss, test_acc = evaluate1(model, test_loader, criterion, alpha, num, device, shuffle)
        test_losses.append(test_loss)
        test_accs.append(test_acc)
        print_tf(f"Epoch {epoch+1}/{num_epochs} - Train Loss: {epoch_loss:.4f} - Train Accuracy: {epoch_acc:.4f} - Test Loss: {test_loss:.4f} - Test Accuracy: {test_acc:.4f} \n")

   
    return train_losses, test_losses, test_accs


def evaluate1(model, dataloader,criterion, alpha ,num, device, shuffle=True):
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0
    with torch.no_grad():
        for images, labels in dataloader:
            images = replicate_image(images, alpha, num, shuffle)
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)

            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            running_loss += loss.item() #* images.size(0)

    loss = running_loss / len(dataloader.dataset)
    accuracy = correct / total
    return loss, accuracy


def plot_losses(train_losses, test_losses, test_accs ):
    plt.figure()
    plt.plot(train_losses, label='Train Loss')
    plt.plot(test_losses, label='Test Loss')
    plt.plot(test_accs, label='Test Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()
    

if __name__ == "__main__":   
    # Check if CUDA is available
    if torch.cuda.is_available():
        device = torch.device("cuda")               # Use the first available GPU
        print("CUDA is available. Using GPU.")
    else:
        device = torch.device("cpu")                # Fallback to CPU
        print("CUDA is not available. Using CPU.")

    for run_idx in range(10):
        print_tf(f"EXPERIMENT 3 RUN = {run_idx} \n")
            
        # Load the MNIST dataset
        transform = transforms.Compose([transforms.ToTensor()])
        data_train = torchvision.datasets.MNIST(root='./data', train=True, transform=transform, download=True)
        data_test = torchvision.datasets.MNIST(root='./data', train=False, transform=transform, download=True)
        train_loader = torch.utils.data.DataLoader(data_train, batch_size=1024, shuffle=True)
        test_loader = torch.utils.data.DataLoader(data_test, batch_size=2048, shuffle=False)

        criterion = nn.CrossEntropyLoss()
        cnn_net_div0 = CNNNet(28,10).to(device)
        optimizer_cnn_div0 = optim.Adam(cnn_net_div0.parameters(), lr=0.001)
        cnn_net_div = CNNNet(28,10).to(device)
        optimizer_cnn_div = optim.Adam(cnn_net_div.parameters(), lr=0.001)

        alpha0 = 0.3; nums = 10; num_epoch = 5
        print(f"alpha = {alpha0}; nums = {nums}; num_epoch = {num_epoch}")
        train_losses_cnn_list_div0=[]; test_losses_cnn_list_div0=[]; test_accs_cnn_list_div0=[]
        train_losses_cnn_list_div=[]; test_losses_cnn_list_div=[]; test_accs_cnn_list_div=[]

        
        for j in range(nums):
            print_tf(f"\n num_obj={j+1} \n")
            print_tf(f"\n Shuffling is NOT Enabled \n")
            # shuffling not enabled
            train_losses_cnn_div0, test_losses_cnn_div0, test_accs_cnn_div0 = train1(cnn_net_div0, train_loader, test_loader, criterion, optimizer_cnn_div0, alpha=alpha0, num=j+1, num_epochs=num_epoch, device=device, shuffle=False)
            train_losses_cnn_list_div0.append(train_losses_cnn_div0);test_losses_cnn_list_div0.append(test_losses_cnn_div0);test_accs_cnn_list_div0.append(test_accs_cnn_div0)
            
            print_tf(f"\n Shuffling is Enabled \n")
            # shuffling enabled
            train_losses_cnn_div, test_losses_cnn_div, test_accs_cnn_div = train1(cnn_net_div, train_loader, test_loader, criterion, optimizer_cnn_div, alpha=alpha0, num=j+1, num_epochs=num_epoch, device=device, shuffle=True)
            train_losses_cnn_list_div.append(train_losses_cnn_div);test_losses_cnn_list_div.append(test_losses_cnn_div);test_accs_cnn_list_div.append(test_accs_cnn_div)
        
        save_dict ={"train_losses_cnn_list_div0":   train_losses_cnn_list_div0,
                    "test_losses_cnn_list_div0":    test_losses_cnn_list_div0,
                    "test_accs_cnn_list_div0":      test_accs_cnn_list_div0,
                    "train_losses_cnn_list_div":    train_losses_cnn_list_div,
                    "test_losses_cnn_list_div":     test_losses_cnn_list_div,
                    "test_accs_cnn_list_div":       test_accs_cnn_list_div,
                    }
        
        import pickle
        # Save dictionary to a pickle file
        with open(f'/project_cnn/exp_3_run={run_idx}.pkl', 'wb') as f:
            pickle.dump(save_dict, f)           