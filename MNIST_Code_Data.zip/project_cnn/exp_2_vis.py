import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
import pickle
import numpy as np
from matplotlib.font_manager import FontProperties
from matplotlib.ticker import MaxNLocator
                    
# Load all the pickle data
pkl_data = []
for seed_idx in range(10):
    # Step 1: Open the pickle file in read-binary mode
    with open(f'/project_cnn/exp_2_run={seed_idx}.pkl', 'rb') as file:
        # Step 2: Load the data from the file
        data = pickle.load(file)
    pkl_data.append(data)

nums = 5

# Load the loss and accuracy values
train_losses_cnn_nums_all=[]
test_losses_cnn_nums_all=[]
test_accs_cnn_nums_all=[]

for seed_idx in range(10):
    train_losses_cnn_nums_seed = []
    test_losses_cnn_nums_seed = []
    test_accs_cnn_nums_seed = []
    for j in range(nums):
        # import pdb; pdb.set_trace()
        train_losses_cnn_nums_seed.append(pkl_data[seed_idx]["train_losses_cnn_list1"][j][-1])
        test_losses_cnn_nums_seed.append(pkl_data[seed_idx]["test_losses_cnn_list1"][j][-1])
        test_accs_cnn_nums_seed.append(pkl_data[seed_idx]["test_accs_cnn_list1"][j][-1])
    train_losses_cnn_nums_all.append(train_losses_cnn_nums_seed)
    test_losses_cnn_nums_all.append(test_losses_cnn_nums_seed)
    test_accs_cnn_nums_all.append(test_accs_cnn_nums_seed)

# Get the mean and standard deviation per run
train_losses_cnn_nums=np.array(train_losses_cnn_nums_all).mean(0)
test_losses_cnn_nums=np.array(test_losses_cnn_nums_all).mean(0)
test_accs_cnn_nums=np.array(test_accs_cnn_nums_all).mean(0)

train_losses_cnn_nums_std=np.array(train_losses_cnn_nums_all).std(0)
test_losses_cnn_nums_std=np.array(test_losses_cnn_nums_all).std(0)
test_accs_cnn_nums_std=np.array(test_accs_cnn_nums_all).std(0)





# Font properties
font_properties_title = {'fontsize': 20, 'fontweight': 'normal', 'fontname': 'serif'}
font_properties_labels = {'fontsize': 18, 'fontweight': 'normal', 'fontname': 'serif'}

# Create FontProperties for serif font
serif_font = FontProperties(family='serif', size=16)

# Create a figure and axis
fig, ax1 = plt.subplots(figsize=(8, 6))
ax1.set_facecolor('#F0F8FF')  # Set the axes background color to a blue shade

# Plot Train and Test Loss
ax1.plot(range(1, nums + 1), train_losses_cnn_nums, label='Train Loss', marker='o', color='blue', alpha=0.8)
ax1.plot(range(1, nums + 1), test_losses_cnn_nums, label='Test Loss', marker='s', color='orange', alpha=0.8)

# Fill between for train loss std
ax1.fill_between(range(1, nums + 1),
                 train_losses_cnn_nums - 1 * train_losses_cnn_nums_std,
                 train_losses_cnn_nums + 1 * train_losses_cnn_nums_std,
                 color='blue', alpha=0.2)

# Fill between for test loss std
ax1.fill_between(range(1, nums + 1),
                 test_losses_cnn_nums - 1 * test_losses_cnn_nums_std,
                 test_losses_cnn_nums + 1 * test_losses_cnn_nums_std,
                 color='orange', alpha=0.2)

# Set labels and title for loss
ax1.set_xlabel('Number of Objects', **font_properties_labels)
ax1.set_ylabel('Loss', **font_properties_labels)
ax1.set_title('Loss and Accuracy vs Number of Objects', **font_properties_title)
ax1.xaxis.set_major_locator(MaxNLocator(integer=True))
ax1.tick_params(axis='both', which='major', labelsize=14, labelcolor='black', labelfontfamily='serif')
plt.grid(color='gray', linestyle='--', linewidth=0.5, alpha=0.7)

# Create a second y-axis for accuracy
ax2 = ax1.twinx()
ax2.plot(range(1, nums + 1), test_accs_cnn_nums * 100, label='Test Accuracy', marker='^', color='green', alpha=0.8)
ax2.fill_between(range(1, nums + 1),
                 test_accs_cnn_nums * 100 - 1 * test_accs_cnn_nums_std * 100,
                 test_accs_cnn_nums * 100 + 1 * test_accs_cnn_nums_std * 100,
                 color='green', alpha=0.2)

# Set labels for accuracy
ax2.set_ylabel('Accuracy (%)', **font_properties_labels, rotation=270, labelpad=20)
ax2.tick_params(axis='y', which='major', labelsize=14, labelcolor='black', labelfontfamily='serif')

# Add legends for both axes
lines_legend_1, labels_legend_1 = ax1.get_legend_handles_labels()
lines_legend_2, labels_legend_2 = ax2.get_legend_handles_labels()
ax1.legend(lines_legend_1 + lines_legend_2, labels_legend_1 + labels_legend_2, fontsize=16, prop=serif_font, loc='right', bbox_to_anchor=(1, 0.60))

plt.tight_layout()  # Adjust layout to make it look better
plt.savefig('/project_cnn/exp_2/loss_accuracy.png', bbox_inches='tight')
plt.show()