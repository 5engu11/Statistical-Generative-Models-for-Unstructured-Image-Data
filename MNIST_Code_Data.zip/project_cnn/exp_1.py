import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
import numpy as np
import matplotlib.pyplot as plt
import torch.optim as optim
import torch.nn.functional as F

from tqdm import tqdm
from datetime import datetime

path = '/project_cnn/exp_1_' + '.txt'


class CNNNet(nn.Module):
    def __init__(self, input_size, num_classes):
        super(CNNNet, self).__init__()
        self.input_size = input_size
        self.conv1 = nn.Conv2d(1, 16, 3, padding=1)
        self.pool = nn.MaxPool2d(2)
        self.conv2 = nn.Conv2d(16, 32, 3, padding=1)
        self.fc = nn.Linear(32 * int(self.input_size/4) * int(self.input_size/4), num_classes)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = self.pool(x)
        x = F.relu(self.conv2(x))
        x = self.pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x

def print_tf(text):
    with open(path, 'a') as file:
        file.write(text)


def scale_image(image, alpha):
    scale_transform = transforms.RandomAffine(degrees=0, scale=(alpha, alpha))
    scaled_image = scale_transform(image)
    return scaled_image


def train(model, train_loader, test_loader, criterion, optimizer, alpha, num_epochs, device):
    model.train()
    train_losses = []
    test_losses = []
    test_accs = []
    
    for epoch in range(num_epochs):
        running_loss = 0.0
        correct = 0
        total = 0
        for images, labels in train_loader:
            images, labels = images.to(device), labels.to(device)
            images = scale_image(images, alpha)
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            running_loss += loss.item() #* images.size(0)

        epoch_loss = running_loss / len(train_loader)
        epoch_acc = correct / total
        train_losses.append(epoch_loss)

      
        test_loss, test_acc = evaluate(model, test_loader, criterion, alpha, device)
        test_losses.append(test_loss)
        test_accs.append(test_acc)
        print_tf(f"Epoch {epoch+1}/{num_epochs} - Train Loss: {epoch_loss:.4f} - Train Accuracy: {epoch_acc:.4f} - Test Loss: {test_loss:.4f} - Test Accuracy: {test_acc:.4f} \n")

    return train_losses, test_losses, test_accs



def evaluate(model, dataloader,criterion, alpha, device):
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0
    with torch.no_grad():
        for images, labels in dataloader:
            images = scale_image(images,alpha)
            images, labels = images.to(device), labels.to(device)
             # Do not scale the images # changed by HP
            outputs = model(images)
            loss = criterion(outputs, labels)

            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            running_loss += loss.item() #* images.size(0)

    eval_loss = running_loss / len(dataloader)  # len(dataloader.dataset) # changed by HP
    accuracy = correct / total
    return eval_loss, accuracy


def plot_losses(train_losses, test_losses, test_accs ):
    plt.figure()
    plt.plot(train_losses, label='Train Loss')
    plt.plot(test_losses, label='Test Loss')
    plt.plot(test_accs, label='Test Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()

    




if __name__ == "__main__":  
    # Config
    num_runs = 10; num_epochs=10

    training, visualize_images, calc_beta = False, True, False
    
    if training:
        # Check if CUDA is available
        if torch.cuda.is_available():
            device = torch.device("cuda")           # Use the first available GPU
            print("CUDA is available. Using GPU.")
        else:
            device = torch.device("cpu")            # Fallback to CPU
            print("CUDA is not available. Using CPU.")
        
        for run_idx in range(num_runs):
            print_tf(f"\n EXPERIMENT 1 RUN = {run_idx} \n")
            
            # Load the MNIST dataset
            transform = transforms.Compose([transforms.ToTensor()])
            data_train = torchvision.datasets.MNIST(root='./data', train=True, transform=transform, download=True)
            data_test = torchvision.datasets.MNIST(root='./data', train=False, transform=transform, download=True)
            train_loader = torch.utils.data.DataLoader(data_train, batch_size=512, shuffle=True)
            test_loader = torch.utils.data.DataLoader(data_test, batch_size=2048, shuffle=False)
            
            
            criterion = nn.CrossEntropyLoss()
            alphas = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
            cnn_net_dict = {} 
            optimizer_cnn = {}
            # for i in range(len(alphas)):
            cnn_net_dict = CNNNet(28,10).to(device)
            optimizer_cnn = optim.Adam(cnn_net_dict.parameters(), lr=0.01)

            train_losses_cnn_list=[]
            test_losses_cnn_list=[]
            test_accs_cnn_list=[]

            
            for j in tqdm(range(len(alphas))):
                print_tf(f"\n alpha={alphas[j]} \n")
                train_losses_cnn, test_losses_cnn, test_accs_cnn = train(cnn_net_dict, train_loader, test_loader, criterion, optimizer_cnn, alpha=alphas[j], num_epochs=num_epochs, device=device)
                train_losses_cnn_list.append(train_losses_cnn)
                test_losses_cnn_list.append(test_losses_cnn)
                test_accs_cnn_list.append(test_accs_cnn)
                
            save_dict ={"train_losses_cnn_list":   train_losses_cnn_list,
                        "test_losses_cnn_list":    test_losses_cnn_list,
                        "test_accs_cnn_list":      test_accs_cnn_list,
                        }
            
            import pickle
            # Save dictionary to a pickle file
            with open(f'/project_cnn/exp_1_run={run_idx}.pkl', 'wb') as f:
                pickle.dump(save_dict, f)
                
    if visualize_images:
        import pdb; pdb.set_trace()
        # Define the transformations
        alphas = [1.0, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8,]
        betas = [0.186, 0.008, 0.017, 0.030, 0.045, 0.067, 0.092, 0.119]

        # Define the transformations
        def scale_image(image, alpha):
            scale_transform = transforms.RandomAffine(degrees=0, scale=(alpha, alpha))
            scaled_image = scale_transform(image)
            return scaled_image
        
        # Load the MNIST dataset
        transform = transforms.Compose([transforms.ToTensor()])
        data_train = torchvision.datasets.MNIST(root='./data', train=True, transform=transform, download=True)
        data_test = torchvision.datasets.MNIST(root='./data', train=False, transform=transform, download=True)
        train_loader = torch.utils.data.DataLoader(data_train, batch_size=512, shuffle=True)
        test_loader = torch.utils.data.DataLoader(data_test, batch_size=2048, shuffle=False)
        
        # Select five random images from the dataset
        selected_indices = np.random.choice(len(data_train), size=5, replace=False)

        # Visualize scaled images
        fig, axes = plt.subplots(nrows=5, ncols=len(betas), figsize=(8, 5), 
                        gridspec_kw={'wspace': 0.15, 'hspace': 0.15})

        for i, idx in enumerate(selected_indices):
            image, label = data_train[idx]
            for j, alpha in enumerate(alphas):
                scaled_image = scale_image(image, alpha)
                axes[i, j].imshow(scaled_image.squeeze().numpy(), cmap='gray')
                axes[i, j].axis('off')
                if i == 0 and j==0:
                    axes[i, j].set_title(f'β: {betas[j]}', fontsize=14)
                elif i == 0:
                    axes[i, j].set_title(f'{betas[j]}', fontsize=14)
        # plt.tight_layout()
        plt.savefig('/project_cnn/exp_1/visuals.png', bbox_inches='tight')
        plt.show()
        
    if calc_beta:
        # Calculate the average proportion of nonzero pixels for all images in the training set
        import pdb; pdb.set_trace()
        # Define the transformations
        alphas = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]

        # Define the transformations
        def scale_image(image, alpha):
            scale_transform = transforms.RandomAffine(degrees=0, scale=(alpha, alpha))
            scaled_image = scale_transform(image)
            return scaled_image
        
        train_bs = 2048
        # Load the MNIST dataset
        transform = transforms.Compose([transforms.ToTensor()])
        data_train = torchvision.datasets.MNIST(root='./data', train=True, transform=transform, download=True)
        data_test = torchvision.datasets.MNIST(root='./data', train=False, transform=transform, download=True)
        train_loader = torch.utils.data.DataLoader(data_train, batch_size=train_bs, shuffle=True)
        test_loader = torch.utils.data.DataLoader(data_test, batch_size=2048, shuffle=False)
        
        beta_per_alpha = {}
        for j, alpha in enumerate(alphas):
            all_nonzero = []
            for images,_ in tqdm(train_loader):
                scaled_image = scale_image(images, alpha)
                all_nonzero.append((scaled_image>0).sum() / (scaled_image.shape[2]*scaled_image.shape[3]*train_bs))
            beta_per_alpha[f"{alpha}"] = np.array(all_nonzero).mean()
            
        print(beta_per_alpha) # {'0.1': 0.0022274714, '0.2': 0.007592379, '0.3': 0.016669365, '0.4': 0.030042814, '0.5': 0.045300487, '0.6': 0.06696698, '0.7': 0.092207484, '0.8': 0.119032875, '0.9': 0.14872862, '1.0': 0.186721}